## Context

Projeto greenfield — não há código ou serviço existente. A API será o ponto de entrada único para operações de clientes, consumida por frontends ou outros serviços. Sem autenticação no escopo inicial.

## Goals / Non-Goals

**Goals:**
- API REST funcional com CRUD completo para clientes
- Validações de email (formato e unicidade) com respostas HTTP semânticas
- Persistência via SQLite gerenciada pelo EF Core 10
- Organização de endpoints por feature para facilitar evolução
- Arquivo de solução `.slnx` pronto para uso no Visual Studio / dotnet CLI

**Non-Goals:**
- Autenticação ou autorização
- Paginação da listagem de clientes
- Soft delete (remoção é permanente)
- Deploy ou containerização
- Testes automatizados

## Decisions

### 1. Minimal APIs em vez de Controllers
**Decisão**: usar Minimal APIs (`app.MapGroup` + extension methods).  
**Alternativa considerada**: Controllers com `[ApiController]`.  
**Razão**: Minimal APIs têm menos cerimônia, são o padrão recomendado no .NET 10 para APIs simples e se alinham ao requisito explícito do projeto.

### 2. Endpoints organizados em `ClientesEndpoints.cs` como extension method
**Decisão**: `WebApplication.MapClientesEndpoints()` chamado no `Program.cs`.  
**Alternativa considerada**: tudo inline no `Program.cs`.  
**Razão**: separa concerns por feature, facilita a localização do código e escala melhor quando novas entidades forem adicionadas.

### 3. `DataCadastro` preenchido pelo servidor
**Decisão**: o campo é definido como `DateTime.UtcNow` na camada da API, nunca aceito no body da requisição.  
**Razão**: evita inconsistências de fuso horário e impede que clientes manipulem a data de cadastro.

### 4. Email duplicado retorna `409 Conflict`
**Decisão**: verificação explícita no banco antes de inserir/atualizar; retorna `409` se outro registro já usa o email.  
**Alternativa considerada**: `400 Bad Request`.  
**Razão**: `409` é semanticamente correto para conflito de recurso existente segundo a RFC 9110.

### 5. SQLite como banco de dados
**Decisão**: SQLite com arquivo local `clientes.db`.  
**Alternativa considerada**: SQL Server LocalDB.  
**Razão**: zero configuração, sem dependências de servidor, ideal para o escopo do projeto.

### 6. Estrutura de diretórios
```
ApiClientes.slnx
└── src/
    └── ApiClientes/
        ├── ApiClientes.csproj
        ├── Program.cs
        ├── Data/
        │   └── AppDbContext.cs
        ├── Models/
        │   └── Cliente.cs
        └── Endpoints/
            └── ClientesEndpoints.cs
```

### 7. Formato de resposta de erro
Erros retornam `ProblemDetails` (padrão ASP.NET Core) para consistência com o ecossistema .NET.

### 8. Seed database via `HasData`
**Decisão**: usar `modelBuilder.Entity<Cliente>().HasData(...)` no `OnModelCreating` do `AppDbContext` com 3 clientes fixos.  
**Alternativa considerada**: inserção manual no startup via código imperativo (verificar se tabela vazia, inserir se necessário).  
**Razão**: `HasData` é a abordagem idiomática do EF Core para dados de seed — declarativa, integrada ao ciclo de vida do modelo, e executada automaticamente pelo `EnsureCreated()` na primeira inicialização. Os 3 clientes devem ter `Id`, `DataCadastro` e emails fixos e estáveis, pois `HasData` requer valores determinísticos.

### 9. Abertura automática do Swagger UI no startup
**Decisão**: configurar `launchSettings.json` com `"launchBrowser": true` e `"launchUrl": "swagger"`.  
**Alternativa considerada**: `Process.Start` programático no `Program.cs`.  
**Razão**: `launchSettings.json` é a forma padrão do .NET para controlar comportamento de inicialização — funciona com `dotnet run`, Visual Studio e Rider sem código extra na aplicação. Não polui o `Program.cs` com código de infraestrutura de desenvolvimento.

## Risks / Trade-offs

- **SQLite sem controle de concorrência avançado** → Aceitável para o escopo; SQLite suporta leituras simultâneas e serializa escritas.
- **Sem paginação** → Listagem retorna todos os clientes; pode ser problema com volume alto de dados. Mitigação: adicionar paginação em iteração futura.
- **Migrations automáticas no startup** → `EnsureCreated` ou `Migrate()` no `Program.cs` simplifica o setup mas não é recomendado para produção. Aceitável para o escopo atual.
- **Seed data com IDs fixos** → `HasData` requer chaves primárias estáticas; re-executar com banco existente é seguro (EF ignora dados já presentes). Deletar o `clientes.db` recria o banco com o seed.
- **Abertura do navegador depende do perfil de execução** → `launchSettings.json` só é respeitado pelo `dotnet run` e IDEs; em produção ou containers o comportamento não se aplica. Nenhum risco, pois é configuração de ambiente de desenvolvimento.
