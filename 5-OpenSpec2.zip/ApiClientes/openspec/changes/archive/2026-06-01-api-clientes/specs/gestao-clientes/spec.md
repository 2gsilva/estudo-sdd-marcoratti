## ADDED Requirements

### Requirement: Criar cliente
O sistema SHALL aceitar uma requisição POST em `/clientes` com `nome` e `email` no body e persistir um novo cliente com `DataCadastro` definido automaticamente como `DateTime.UtcNow`.

#### Scenario: Criação bem-sucedida
- **WHEN** uma requisição POST é enviada para `/clientes` com `nome` válido e `email` válido e único
- **THEN** o sistema cria o cliente com `DataCadastro = DateTime.UtcNow` e retorna `201 Created` com o cliente criado no body

#### Scenario: Nome ausente ou vazio
- **WHEN** uma requisição POST é enviada para `/clientes` sem `nome` ou com `nome` vazio
- **THEN** o sistema retorna `400 Bad Request`

#### Scenario: Email sem arroba
- **WHEN** uma requisição POST é enviada para `/clientes` com `email` que não contém `@`
- **THEN** o sistema retorna `400 Bad Request`

#### Scenario: Email já cadastrado
- **WHEN** uma requisição POST é enviada para `/clientes` com `email` que já pertence a outro cliente
- **THEN** o sistema retorna `409 Conflict`

### Requirement: Listar clientes
O sistema SHALL retornar todos os clientes cadastrados em uma requisição GET para `/clientes`.

#### Scenario: Lista com registros
- **WHEN** uma requisição GET é enviada para `/clientes` e existem clientes cadastrados
- **THEN** o sistema retorna `200 OK` com array de todos os clientes

#### Scenario: Lista vazia
- **WHEN** uma requisição GET é enviada para `/clientes` e não há clientes cadastrados
- **THEN** o sistema retorna `200 OK` com array vazio

### Requirement: Obter cliente por ID
O sistema SHALL retornar um único cliente identificado pelo `id` em uma requisição GET para `/clientes/{id}`.

#### Scenario: Cliente encontrado
- **WHEN** uma requisição GET é enviada para `/clientes/{id}` e existe um cliente com aquele `id`
- **THEN** o sistema retorna `200 OK` com os dados do cliente

#### Scenario: Cliente não encontrado
- **WHEN** uma requisição GET é enviada para `/clientes/{id}` e não existe cliente com aquele `id`
- **THEN** o sistema retorna `404 Not Found`

### Requirement: Atualizar cliente
O sistema SHALL atualizar `nome` e `email` de um cliente existente em uma requisição PUT para `/clientes/{id}`. O campo `DataCadastro` SHALL permanecer inalterado.

#### Scenario: Atualização bem-sucedida
- **WHEN** uma requisição PUT é enviada para `/clientes/{id}` com `nome` válido e `email` válido e único
- **THEN** o sistema atualiza o cliente mantendo `DataCadastro` original e retorna `200 OK` com o cliente atualizado

#### Scenario: Cliente não encontrado
- **WHEN** uma requisição PUT é enviada para `/clientes/{id}` e não existe cliente com aquele `id`
- **THEN** o sistema retorna `404 Not Found`

#### Scenario: Email sem arroba na atualização
- **WHEN** uma requisição PUT é enviada para `/clientes/{id}` com `email` que não contém `@`
- **THEN** o sistema retorna `400 Bad Request`

#### Scenario: Email já usado por outro cliente
- **WHEN** uma requisição PUT é enviada para `/clientes/{id}` com `email` que já pertence a um cliente diferente
- **THEN** o sistema retorna `409 Conflict`

### Requirement: Remover cliente
O sistema SHALL remover permanentemente um cliente em uma requisição DELETE para `/clientes/{id}`.

#### Scenario: Remoção bem-sucedida
- **WHEN** uma requisição DELETE é enviada para `/clientes/{id}` e existe um cliente com aquele `id`
- **THEN** o sistema remove o cliente e retorna `204 No Content`

#### Scenario: Cliente não encontrado
- **WHEN** uma requisição DELETE é enviada para `/clientes/{id}` e não existe cliente com aquele `id`
- **THEN** o sistema retorna `404 Not Found`
