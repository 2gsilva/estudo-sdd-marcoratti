## Why

Criar uma API REST de gerenciamento de clientes que sirva como backend para cadastro, consulta, atualização e remoção de clientes. A necessidade surge da ausência de um serviço centralizado para persistir e expor dados de clientes via HTTP.

## What Changes

- Novo projeto ASP.NET Core 10 com Minimal APIs
- Arquivo de solução `.slnx` englobando o projeto
- Entidade `Cliente` com Id, Nome, Email e DataCadastro
- Cinco endpoints REST cobrindo CRUD completo
- Validação de formato de email (presença de `@`)
- Restrição de unicidade de email com resposta `409 Conflict`
- Resposta `404 Not Found` para recursos inexistentes
- Persistência via EF Core 10 com banco SQLite
- Endpoints organizados por feature em `ClientesEndpoints.cs`
- Seed database com `HasData`: 3 clientes fixos inseridos automaticamente na criação do banco
- Abertura automática do navegador apontando para o Swagger UI ao iniciar a aplicação

## Capabilities

### New Capabilities

- `gestao-clientes`: CRUD completo de clientes via HTTP REST com validações de email e unicidade

### Modified Capabilities

## Impact

- **Novo projeto**: `src/ApiClientes/ApiClientes.csproj`
- **Nova solução**: `ApiClientes.slnx`
- **Banco de dados**: arquivo SQLite gerado localmente (`clientes.db`) com 3 clientes pré-cadastrados via seed
- **Dependências**: `Microsoft.EntityFrameworkCore.Sqlite`, `Microsoft.EntityFrameworkCore.Design`
- **Endpoints expostos**: `POST`, `GET`, `GET/{id}`, `PUT/{id}`, `DELETE/{id}` em `/clientes`
- **launchSettings.json**: configurado com `launchBrowser: true` e `launchUrl: swagger` para abertura automática do Swagger UI
