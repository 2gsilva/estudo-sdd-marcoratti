## 1. Estrutura do Projeto

- [x] 1.1 Criar o arquivo de solução `ApiClientes.slnx` na raiz do projeto
- [x] 1.2 Criar o projeto `src/ApiClientes/ApiClientes.csproj` com target `net10.0`
- [x] 1.3 Adicionar o projeto à solução
- [x] 1.4 Adicionar pacotes NuGet: `Microsoft.EntityFrameworkCore.Sqlite` e `Microsoft.EntityFrameworkCore.Design`

## 2. Modelo e Contexto de Dados

- [x] 2.1 Criar `src/ApiClientes/Models/Cliente.cs` com propriedades `Id`, `Nome`, `Email` e `DataCadastro`
- [x] 2.2 Criar `src/ApiClientes/Data/AppDbContext.cs` com `DbSet<Cliente>` e índice único em `Email`
- [x] 2.3 Adicionar seed data no `OnModelCreating` com `HasData`: 3 clientes fixos (Id, Nome, Email e DataCadastro determinísticos)
- [x] 2.4 Configurar a string de conexão SQLite no `appsettings.json`

## 3. Configuração da Aplicação

- [x] 3.1 Configurar `Program.cs` com registro do `AppDbContext` usando SQLite
- [x] 3.2 Adicionar chamada a `db.Database.EnsureCreated()` no startup para criar o banco e aplicar o seed
- [x] 3.3 Registrar os endpoints chamando `app.MapClientesEndpoints()` no `Program.cs`
- [x] 3.4 Configurar Swagger/OpenAPI para desenvolvimento
- [x] 3.5 Configurar `Properties/launchSettings.json` com `"launchBrowser": true` e `"launchUrl": "swagger"` no perfil http

## 4. Endpoints CRUD

- [x] 4.1 Criar `src/ApiClientes/Endpoints/ClientesEndpoints.cs` com o método de extensão `MapClientesEndpoints`
- [x] 4.2 Implementar `POST /clientes`: validar `nome` obrigatório, validar `@` no email, verificar unicidade, salvar com `DataCadastro = DateTime.UtcNow`, retornar `201 Created`
- [x] 4.3 Implementar `GET /clientes`: retornar lista completa de clientes com `200 OK`
- [x] 4.4 Implementar `GET /clientes/{id}`: retornar cliente por id ou `404 Not Found`
- [x] 4.5 Implementar `PUT /clientes/{id}`: retornar `404` se não encontrar, validar `@` no email, verificar unicidade contra outros clientes, atualizar `nome` e `email` mantendo `DataCadastro`, retornar `200 OK`
- [x] 4.6 Implementar `DELETE /clientes/{id}`: retornar `404` se não encontrar, remover e retornar `204 No Content`

## 5. Validação e Respostas de Erro

- [x] 5.1 Garantir que email sem `@` retorna `400 Bad Request` no POST e no PUT
- [x] 5.2 Garantir que email duplicado retorna `409 Conflict` no POST e no PUT
- [x] 5.3 Garantir que id inexistente retorna `404 Not Found` no GET/{id}, PUT e DELETE

## 6. Verificação Final

- [x] 6.1 Executar `dotnet build` e corrigir eventuais erros de compilação
- [x] 6.2 Executar a aplicação com `dotnet run` e validar todos os endpoints via Swagger UI
- [x] 6.3 Testar cenários de erro: email inválido (400), email duplicado (409), id inexistente (404)
