using ApiClientes.Models;
using Microsoft.EntityFrameworkCore;

namespace ApiClientes.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Cliente> Clientes => Set<Cliente>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasIndex(c => c.Email).IsUnique();

            entity.HasData(
                new Cliente { Id = 1, Nome = "Ana Silva",    Email = "ana.silva@email.com",    DataCadastro = new DateTime(2024, 1, 10, 0, 0, 0, DateTimeKind.Utc) },
                new Cliente { Id = 2, Nome = "Bruno Costa",  Email = "bruno.costa@email.com",  DataCadastro = new DateTime(2024, 2, 15, 0, 0, 0, DateTimeKind.Utc) },
                new Cliente { Id = 3, Nome = "Carla Mendes", Email = "carla.mendes@email.com", DataCadastro = new DateTime(2024, 3, 20, 0, 0, 0, DateTimeKind.Utc) }
            );
        });
    }
}
