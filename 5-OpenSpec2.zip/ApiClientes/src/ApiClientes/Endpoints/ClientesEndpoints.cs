using ApiClientes.Data;
using ApiClientes.Models;
using Microsoft.EntityFrameworkCore;

namespace ApiClientes.Endpoints;

public static class ClientesEndpoints
{
    public static void MapClientesEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/clientes").WithTags("Clientes");

        group.MapPost("/", async (ClienteRequest request, AppDbContext db) =>
        {
            if (string.IsNullOrWhiteSpace(request.Nome))
                return Results.BadRequest("O campo Nome é obrigatório.");

            if (string.IsNullOrWhiteSpace(request.Email) || !request.Email.Contains('@'))
                return Results.BadRequest("O campo Email deve conter '@'.");

            if (await db.Clientes.AnyAsync(c => c.Email == request.Email))
                return Results.Conflict("Já existe um cliente com este email.");

            var cliente = new Cliente
            {
                Nome = request.Nome,
                Email = request.Email,
                DataCadastro = DateTime.UtcNow
            };

            db.Clientes.Add(cliente);
            await db.SaveChangesAsync();

            return Results.Created($"/clientes/{cliente.Id}", cliente);
        });

        group.MapGet("/", async (AppDbContext db) =>
            Results.Ok(await db.Clientes.ToListAsync()));

        group.MapGet("/{id:int}", async (int id, AppDbContext db) =>
        {
            var cliente = await db.Clientes.FindAsync(id);
            return cliente is null ? Results.NotFound() : Results.Ok(cliente);
        });

        group.MapPut("/{id:int}", async (int id, ClienteRequest request, AppDbContext db) =>
        {
            var cliente = await db.Clientes.FindAsync(id);
            if (cliente is null)
                return Results.NotFound();

            if (string.IsNullOrWhiteSpace(request.Nome))
                return Results.BadRequest("O campo Nome é obrigatório.");

            if (string.IsNullOrWhiteSpace(request.Email) || !request.Email.Contains('@'))
                return Results.BadRequest("O campo Email deve conter '@'.");

            if (await db.Clientes.AnyAsync(c => c.Email == request.Email && c.Id != id))
                return Results.Conflict("Já existe um cliente com este email.");

            cliente.Nome = request.Nome;
            cliente.Email = request.Email;

            await db.SaveChangesAsync();
            return Results.Ok(cliente);
        });

        group.MapDelete("/{id:int}", async (int id, AppDbContext db) =>
        {
            var cliente = await db.Clientes.FindAsync(id);
            if (cliente is null)
                return Results.NotFound();

            db.Clientes.Remove(cliente);
            await db.SaveChangesAsync();
            return Results.NoContent();
        });
    }
}

record ClienteRequest(string Nome, string Email);
